local QBCore = exports['newcore-core']:GetCoreObject()
local plateModel = "p_ld_id_card_01"
local plateModel2 = "p_ld_id_card_01"
local animDict = "missfbi_s4mop"
local animName = "swipe_card"
local plate_net = nil


local open = false

RegisterNetEvent('newcore-cards:open')
AddEventHandler('newcore-cards:open', function(data, type)
	open = true
	SendNUIMessage({
		action = "open",
		name = data.name,
		csn = data.csn,
		national = data.national,
		birth = data.birth,
		gender = data.gender,
		image = data.image
	})
	QBCore.Functions.Notify("اضغط على [Backspace] لإخفاء البطاقة")
	Wait(15000)
	SendNUIMessage({
		action = "close"
	})
	open = false
end)

Citizen.CreateThread(function()
	while true do
		Wait(3)
		if open then
			if IsControlJustReleased(0, 322) and open or IsControlJustReleased(0, 177) and open then
				SendNUIMessage({
					action = "close"
				})
				open = false
			end
		else
			Wait(500)
		end
	end
end)

RegisterNetEvent('newcore-cards:showIdCard1')
AddEventHandler('newcore-cards:showIdCard1', function(item)
	local player, distance = QBCore.Functions.GetClosestPlayer()
	if distance ~= -1 and distance <= 3.0 then
		TriggerServerEvent('newcore-cards:open', GetPlayerServerId(PlayerId()), GetPlayerServerId(player), item)
        TriggerServerEvent('newcore-cards:open', GetPlayerServerId(PlayerId()), GetPlayerServerId(PlayerId()), item)
	else 
		TriggerServerEvent('newcore-cards:open', GetPlayerServerId(PlayerId()), GetPlayerServerId(PlayerId()), item)
	end
end)

RegisterNetEvent('newcore-cards:showIdCard2')
AddEventHandler('newcore-cards:showIdCard2', function(item)
	local player, distance = QBCore.Functions.GetClosestPlayer()
	if distance ~= -1 and distance <= 3.0 then
		TriggerServerEvent('newcore-cards:open2', GetPlayerServerId(PlayerId()), GetPlayerServerId(player), item)
        TriggerServerEvent('newcore-cards:open2', GetPlayerServerId(PlayerId()), GetPlayerServerId(PlayerId()), item)
	else 
		TriggerServerEvent('newcore-cards:open2', GetPlayerServerId(PlayerId()), GetPlayerServerId(PlayerId()), item)
	end
end)

RegisterNetEvent('newcore-cards:showIdCard3')
AddEventHandler('newcore-cards:showIdCard3', function(item)
	local player, distance = QBCore.Functions.GetClosestPlayer()
	if distance ~= -1 and distance <= 3.0 then
		TriggerServerEvent('newcore-cards:open3', GetPlayerServerId(PlayerId()), GetPlayerServerId(player), item)
        TriggerServerEvent('newcore-cards:open3', GetPlayerServerId(PlayerId()), GetPlayerServerId(PlayerId()), item)
	else 
		TriggerServerEvent('newcore-cards:open3', GetPlayerServerId(PlayerId()), GetPlayerServerId(PlayerId()), item)
	end
end)

RegisterNetEvent('newcore-cards:showIdCard4')
AddEventHandler('newcore-cards:showIdCard4', function(item)
	local player, distance = QBCore.Functions.GetClosestPlayer()
	if distance ~= -1 and distance <= 3.0 then
		TriggerServerEvent('newcore-cards:open4', GetPlayerServerId(PlayerId()), GetPlayerServerId(player), item)
        TriggerServerEvent('newcore-cards:open4', GetPlayerServerId(PlayerId()), GetPlayerServerId(PlayerId()), item)
	else 
		TriggerServerEvent('newcore-cards:open4', GetPlayerServerId(PlayerId()), GetPlayerServerId(PlayerId()), item)
	end
end)

RegisterNetEvent('newcore-cards:showIdCard5')
AddEventHandler('newcore-cards:showIdCard5', function(item)
	local player, distance = QBCore.Functions.GetClosestPlayer()
	if distance ~= -1 and distance <= 3.0 then
		TriggerServerEvent('newcore-cards:open5', GetPlayerServerId(PlayerId()), GetPlayerServerId(player), item)
        TriggerServerEvent('newcore-cards:open5', GetPlayerServerId(PlayerId()), GetPlayerServerId(PlayerId()), item)
	else 
		TriggerServerEvent('newcore-cards:open5', GetPlayerServerId(PlayerId()), GetPlayerServerId(PlayerId()), item)
	end
end)

RegisterNetEvent('newcore-cards:showIdCard6')
AddEventHandler('newcore-cards:showIdCard6', function(item)
	local player, distance = QBCore.Functions.GetClosestPlayer()
	if distance ~= -1 and distance <= 3.0 then
		TriggerServerEvent('newcore-cards:open6', GetPlayerServerId(PlayerId()), GetPlayerServerId(player), item)
        TriggerServerEvent('newcore-cards:open6', GetPlayerServerId(PlayerId()), GetPlayerServerId(PlayerId()), item)
	else 
		TriggerServerEvent('newcore-cards:open6', GetPlayerServerId(PlayerId()), GetPlayerServerId(PlayerId()), item)
	end
end)



function startAnim()
    RequestModel(GetHashKey(plateModel))
    while not HasModelLoaded(GetHashKey(plateModel)) do
        Citizen.Wait(100)
    end
	ClearPedSecondaryTask(PlayerPedId())
	RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do
        Citizen.Wait(100)
    end
    local playerPed = PlayerPedId()
    local plyCoords = GetOffsetFromEntityInWorldCoords(playerPed, 0.0, 0.0, -5.0)
    local platespawned = CreateObject(GetHashKey(plateModel), plyCoords.x, plyCoords.y, plyCoords.z, 0, 0, 0)
    Citizen.Wait(1000)
    local netid = ObjToNet(platespawned)
    SetNetworkIdExistsOnAllMachines(netid, true)
    SetNetworkIdCanMigrate(netid, false)
    TaskPlayAnim(playerPed, 1.0, -1, -1, 50, 0, 0, 0, 0)
    TaskPlayAnim(playerPed, animDict, animName, 1.0, 1.0, -1, 50, 0, 0, 0, 0)
    Citizen.Wait(800)
    AttachEntityToEntity(platespawned, playerPed, GetPedBoneIndex(playerPed, 28422), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1, 1, 0, 1, 0, 1)
    plate_net = netid
    Citizen.Wait(3000)
    ClearPedSecondaryTask(playerPed)
    DetachEntity(NetToObj(plate_net), 1, 1)
    DeleteEntity(NetToObj(plate_net))
	DeleteEntity(platespawned)
	DeleteEntity(netid)

    plate_net = nil

	-- RequestAnimDict("paper_1_rcm_alt1-7")
	-- while not HasAnimDictLoaded("paper_1_rcm_alt1-7") do
	-- 	Citizen.Wait(10)
	-- end
	-- TaskPlayAnim(PlayerPedId(), "paper_1_rcm_alt1-7", "player_one_dual-7", 8.0, -8.0, -1, 49, 0, false, false, false)
	-- Citizen.Wait(1000)
	-- local badge = CreateObject(GetHashKey("prop_fib_badge"), 0, 0, 0, true, true, true)
	-- AttachEntityToEntity(badge, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 57005),0.15, 0.02, -0.05, 105.0, -20.0, 90.0, true, true, false, true, 1, true)
	-- Citizen.Wait(8150)
	-- ClearPedTasks(PlayerPedId())
	-- DeleteEntity(badge)
end

RegisterNetEvent('newcore-cards:showIdCard')
AddEventHandler('newcore-cards:showIdCard', function(item)
	TriggerEvent('newcore-cards:showIdCard1', item)
	startAnim()
end)

RegisterNetEvent('newcore-cards:showDriver')
AddEventHandler('newcore-cards:showDriver', function(item)
	TriggerEvent('newcore-cards:showIdCard2', item)
	startAnim()
end)

RegisterNetEvent('newcore-cards:showBusiness')
AddEventHandler('newcore-cards:showBusiness', function(item)
	TriggerEvent('newcore-cards:showIdCard3', item)
	startAnim()
end)

RegisterNetEvent('newcore-cards:showeapon')
AddEventHandler('newcore-cards:showeapon', function(item)
	TriggerEvent('newcore-cards:showIdCard4', item)
	startAnim()
end)


RegisterNetEvent('newcore-cards:showHunting')
AddEventHandler('newcore-cards:showHunting', function(item)
	TriggerEvent('newcore-cards:showIdCard5', item)
	startAnim()
end)

RegisterNetEvent('newcore-cards:showLawyer')
AddEventHandler('newcore-cards:showLawyer', function(item)
	TriggerEvent('newcore-cards:showIdCard6', item)
	startAnim()
end)



function loadAnimDict( dict )
    while ( not HasAnimDictLoaded( dict ) ) do
        RequestAnimDict( dict )
        Citizen.Wait( 0 )
    end
end

RegisterNetEvent('newcore-cards:showImage')
AddEventHandler('newcore-cards:showImage', function(playerID)
	local posx, posy = 0, 0.26
	local width, height = 0.07, 0.14
	local x, y = GetActiveScreenResolution()
	posx, posy = 0.100, 0.39
	width, height = 0.07, 0.14	
		-- posx, posy = 0.096, 0.366
		-- width, height = 0.059, 0.156

	local playerPed = GetPlayerPed(GetPlayerFromServerId( playerID ))
	local handle = RegisterPedheadshot(playerPed)

	if not IsPedheadshotValid(handle) then
		-- print(handle)
	end

	while not IsPedheadshotReady (handle) do
		Wait (100)
	end
	local headshot = GetPedheadshotTxdString (handle)
	while open do
		Wait (3)
		DrawSprite (headshot, headshot, posx, posy, width, height, 0.0, 255, 255, 255, 1000)
	end
	if not open then
		UnregisterPedheadshot(handle)
	end
end)