local QBCore = exports['newcore-core']:GetCoreObject()



QBCore.Functions.CreateUseableItem('id_card', function(source, item)
	local Player = QBCore.Functions.GetPlayer(source)
	TriggerClientEvent('newcore-cards:showIdCard', source, item.info)
end)
RegisterServerEvent('newcore-cards:open')
AddEventHandler('newcore-cards:open', function(ID, targetID, character)
	local Player = QBCore.Functions.GetPlayer(ID)
	local gender = "Man"
	if character.gender == 1 then
		gender = "Woman"
	end
	local csn = character.citizenid
	local name = character.firstname
	local name2 = character.lastname
	local birth = character.birthdate
	local gender = gender
	local national = character.nationality

	local data = {
		name = "Name: "..name.." "..name2,
		csn = "CNS | "..csn.."",
		national = "From : "..national,
		birth = character.birthdate,
		gender = gender,
		image = "idcard"
	}
	TriggerClientEvent('newcore-cards:open', targetID, data)
	TriggerClientEvent('newcore-cards:showImage', targetID, source)
end)



QBCore.Functions.CreateUseableItem('driver_license', function(source, item)
	local Player = QBCore.Functions.GetPlayer(source)
	TriggerClientEvent('newcore-cards:showDriver', source, item.info)
end)
RegisterServerEvent('newcore-cards:open2')
AddEventHandler('newcore-cards:open2', function(ID, targetID, character)
	local Player = QBCore.Functions.GetPlayer(ID)
	local csn = ''
	if character.citizenid then
		csn = "CNS | "..character.citizenid..""
	else
		csn = ''
	end
	local name = character.firstname
	local name2 = character.lastname
	local birth = character.birthdate

	local data = {
		name = "Name: "..name.." "..name2,
		csn = birth,
		national = character.type,
		birth = csn,
		gender = '',
		image = "driver"
	}
	TriggerClientEvent('newcore-cards:open', targetID, data)
	TriggerClientEvent('newcore-cards:showImage', targetID, source)
end)

QBCore.Functions.CreateUseableItem('business_license', function(source, item)
	local Player = QBCore.Functions.GetPlayer(source)
	TriggerClientEvent('newcore-cards:showBusiness', source, item.info)
end)
RegisterServerEvent('newcore-cards:open3')
AddEventHandler('newcore-cards:open3', function(ID, targetID, character)
	local Player = QBCore.Functions.GetPlayer(ID)
	local name = character.firstname
	local name2 = character.lastname
	local birth = character.birthdate
	local citizenid = character.citizenid

	local data = {
		name = "Name: "..name.." "..name2,
		csn = "CNS | "..citizenid,
		national = birth,
		birth = character.type,
		gender = '',
		image = "business"
	}
	TriggerClientEvent('newcore-cards:open', targetID, data)
	TriggerClientEvent('newcore-cards:showImage', targetID, source)
end)


QBCore.Functions.CreateUseableItem('weaponlicense', function(source, item)
	local Player = QBCore.Functions.GetPlayer(source)
	TriggerClientEvent('newcore-cards:showeapon', source, item.info)
end)
RegisterServerEvent('newcore-cards:open4')
AddEventHandler('newcore-cards:open4', function(ID, targetID, character)
	local Player = QBCore.Functions.GetPlayer(ID)
	local name = character.firstname
	local name2 = character.lastname
	local birth = character.birthdate
	local citizenid = character.citizenid

	local data = {
		name = "Name: "..name.." "..name2,
		csn = "CNS | "..citizenid,
		national = birth,
		birth = character.type,
		gender = '',
		image = "weapon"
	}
	TriggerClientEvent('newcore-cards:open', targetID, data)
	TriggerClientEvent('newcore-cards:showImage', targetID, source)
end)


QBCore.Functions.CreateUseableItem('hunting_license', function(source, item)
	local Player = QBCore.Functions.GetPlayer(source)
	TriggerClientEvent('newcore-cards:showHunting', source, item.info)
end)
RegisterServerEvent('newcore-cards:open5')
AddEventHandler('newcore-cards:open5', function(ID, targetID, character)
	local Player = QBCore.Functions.GetPlayer(ID)
	local name = character.firstname
	local name2 = character.lastname
	local birth = character.birthdate
	local citizenid = character.citizenid

	local data = {
		name = "Name: "..name.." "..name2,
		csn = "CNS | "..citizenid,
		national = birth,
		birth = character.type,
		gender = '',
		image = "hunting"
	}
	TriggerClientEvent('newcore-cards:open', targetID, data)
	TriggerClientEvent('newcore-cards:showImage', targetID, source)
end)




QBCore.Functions.CreateUseableItem('lawyerpass', function(source, item)
	local Player = QBCore.Functions.GetPlayer(source)
	TriggerClientEvent('newcore-cards:showLawyer', source, item.info)
end)
RegisterServerEvent('newcore-cards:open6')
AddEventHandler('newcore-cards:open6', function(ID, targetID, character)
	local Player = QBCore.Functions.GetPlayer(ID)
	local name = character.firstname
	local name2 = character.lastname
	local birth = character.birthdate
	local citizenid = character.citizenid

	local data = {
		name = "Name: "..name.." "..name2,
		csn = "CNS | "..citizenid,
		national = birth,
		birth = character.type,
		gender = '',
		image = "lawyer"
	}
	TriggerClientEvent('newcore-cards:open', targetID, data)
	TriggerClientEvent('newcore-cards:showImage', targetID, source)
end)
