const open = (data) => {
  $('#name').css('color', '#282828');
  $('#name').text(data.name);
  $('#csn').text(data.csn);
  $('#national').text(data.national);
  $('#birth').text(data.birth);
  $('#gender').text(data.gender);
  $('#signature').text(data.name);

  $('#id-card').css('background', 'url(assets/images/'+data.image+'.png)');
  $('#id-card').show();

	if (data.image == 'weapon' || data.image == 'business')  {
    $('#name').css('color', 'white');
    $('#csn').css('color', 'white');
    $('#national').css('color', 'white');
    $('#birth').css('color', 'white');
    $('#gender').css('color', 'white');
    $('#signature').css('color', 'white');
  }   else {
    $('#name').css('color', 'black');
    $('#csn').css('color', 'black');
    $('#national').css('color', 'black');
    $('#birth').css('color', 'black');
    $('#gender').css('color', 'black');
    $('#signature').css('color', 'black');
  }
  
}


const close = () => {
  $('#name').text('');
  $('#grade').text('');
  $('#badgenumber').text('');
  $('#dob').text('');
  $('#height').text('');
  $('#signature').text('');
  $('#sex').text('');
  $('#id-card').hide();
  $('#licenses').html('');
}

$(document).ready(function(){
    window.addEventListener('message', function(event) {
        switch(event.data.action) {
            case "open":
                open(event.data);
                break;
            case "close":
                close();
                break;
        }
    })
});